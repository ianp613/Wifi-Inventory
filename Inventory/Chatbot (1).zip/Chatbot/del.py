import os

cwd = os.getcwd()
cwd= cwd.replace("\Chatbot","")
print("Current directory:", cwd)