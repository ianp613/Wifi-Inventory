

img_path= {}

img_path["annex"]= "12/12/12.png"
img_path["annex2"]= "13/13/13.png"

for key, value in img_path.items():
    print(key, value)