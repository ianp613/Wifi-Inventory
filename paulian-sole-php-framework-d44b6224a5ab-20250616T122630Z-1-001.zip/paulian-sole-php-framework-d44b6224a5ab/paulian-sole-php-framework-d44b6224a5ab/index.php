<?php
    include "unite/sole.php";
    Route::load(Sole::class);
?>