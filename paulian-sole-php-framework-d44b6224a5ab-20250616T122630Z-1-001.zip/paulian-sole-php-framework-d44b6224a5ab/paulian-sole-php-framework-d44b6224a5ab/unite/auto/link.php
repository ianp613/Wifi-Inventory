<link rel="stylesheet" href="../../public/addons/font-awesome-4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="../../public/assets/css/sole.accessories/crowd.css">
<link rel="stylesheet" href="../../public/assets/css/sole.accessories/paintball.css">
<link rel="stylesheet" href="../../public/assets/css/sole.accessories/rain.css">
<link rel="stylesheet" href="../../public/assets/css/sole.boostrap/bootstrap.css">
<link rel="stylesheet" href="../../public/assets/css/sole.css">
<link rel="stylesheet" href="../../public/assets/css/sole.game/matchpuzzle.css">
<link rel="stylesheet" href="../../public/assets/css/sole.game/snake.css">
<link rel="stylesheet" href="../../public/assets/css/sole.responsive/responsive.css">
<link rel="stylesheet" href="../../public/assets/css/sole.splash/splash.css">
<link rel="stylesheet" href="../../public/assets/css/sole.toast/toastr.css">
<link rel="stylesheet" href="../../public/assets/css/sole.toast/toastr.min.css">
<link rel="stylesheet" href="../../public/app/app.css">
<script src="../../public/assets/js/sole._jquery/jquery-3.3.1.min.js"></script>
<script src="../../public/assets/js/sole.accessories/crowd.js"></script>
<script src="../../public/assets/js/sole.accessories/paintball.js"></script>
<script src="../../public/assets/js/sole.accessories/rain.js"></script>
<script src="../../public/assets/js/sole.bootstrap/bootstrap.min.js"></script>
<script src="../../public/assets/js/sole.console/console.js"></script>
<script src="../../public/assets/js/sole.game/matchpuzzle.js"></script>
<script src="../../public/assets/js/sole.game/snake.js"></script>
<script src="../../public/assets/js/sole.js"></script>
<script src="../../public/assets/js/sole.landing&error/landing&error.js"></script>
<script src="../../public/assets/js/sole.log/log.js"></script>
<script src="../../public/assets/js/sole.particle/particles.min.js"></script>
<script src="../../public/assets/js/sole.responsive/responsive.js"></script>
<script src="../../public/assets/js/sole.splash/splash.js"></script>
<script src="../../public/assets/js/sole.splash/splash_img.js"></script>
<script src="../../public/assets/js/sole.toast/toastr.min.js"></script>
<script src="../../public/app/app.js"></script>
