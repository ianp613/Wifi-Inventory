<?php
    class Disc{
        public static function index(){
            include("unite/chain/disc");
        }
    }
?>