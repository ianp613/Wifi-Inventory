<?php
    Migrate::$migration = [
        "UserMigration",
        "EquipmentMigration",
        "EquipmentEntryMigration",
        "ip_networkMigration",
        "ip_addressMigration",
        "RoutersMigration",
        "ISPMigration",
        "SettingsMigration"
    ];
    class UserMigration
    {
        public static function index(){
            Migrate::attrib_table("user");
            Migrate::attrib_string(1000);
            Migrate::string("name");
            Migrate::string("username");
            Migrate::string("password");
        }
    }

    class EquipmentMigration
    {
        public static function index(){
            Migrate::attrib_table("equipment");
            Migrate::attrib_string(255);
            Migrate::string("name");
        }
    }

    class EquipmentEntryMigration
    {
        public static function index(){
            Migrate::attrib_table("equipment_entry");
            Migrate::attrib_string(255);
            Migrate::string("eid");
            Migrate::string("description");
            Migrate::string("model_no");
            Migrate::string("barcode");
            Migrate::string("specifications");
            Migrate::string("status");
        }
    }

    class ip_networkMigration
    {
        public static function index(){
            Migrate::attrib_table("ip_network");
            Migrate::attrib_string(255);
            Migrate::string("rid");
            Migrate::string("name");
            Migrate::string("from");
            Migrate::string("to");
            Migrate::string("subnet");
            Migrate::string("router");
        }
    }

    class ip_addressMigration
    {
        public static function index(){
            Migrate::attrib_table("ip_address");
            Migrate::attrib_string(255);
            Migrate::string("nid");
            Migrate::string("ip");
            Migrate::string("subnet");
            Migrate::string("hostname");
            Migrate::string("site");
            Migrate::string("server");
            Migrate::string("status");
            Migrate::string("remarks");
            Migrate::string("webmgmtpt");
            Migrate::string("username");
            Migrate::string("password");
        }
    }

    class RoutersMigration
    {
        public static function index(){
            Migrate::attrib_table("routers");
            Migrate::attrib_string(255);
            Migrate::string("name");
            Migrate::string("ip");
            Migrate::string("subnet");
            Migrate::string("wan1");
            Migrate::string("wan2");
            Migrate::string("active");
        }
    }

    class ISPMigration
    {
        public static function index(){
            Migrate::attrib_table("isp");
            Migrate::attrib_string(255);
            Migrate::string("isp_name");
            Migrate::string("name");
            Migrate::string("wan_ip");
            Migrate::string("subnet");
            Migrate::string("gateway");
            Migrate::string("dns1");
            Migrate::string("dns2");
            Migrate::string("webmgmtpt");
        }
    }

    class SettingsMigration
    {
        public static function index(){
            Migrate::attrib_table("settings");
            Migrate::attrib_string(255);
            Migrate::string("sound");
            Migrate::string("theme");
        }
    }
?>