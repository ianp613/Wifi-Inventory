/* Handles All Framework's JS */
if(window.location.href.split("/").pop() == "Sole"){
    sole.splash()
}