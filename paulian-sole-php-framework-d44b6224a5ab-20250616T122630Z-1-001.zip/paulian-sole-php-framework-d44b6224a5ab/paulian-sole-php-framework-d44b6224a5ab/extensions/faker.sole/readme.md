Sole PHP Faker Copyright © PID 2021
--------------------------------------------------------------------------------------
Note: This library extention works only with sole php framework version 6.0 and above.