Sole PHP QRCode Copyright © PID 2021
--------------------------------------------------------------------------------------
Note: This library extention works only with sole php framework version 6.0 and above.
      Before using qrcode.sole library, make sure that your php GD2 extension is enabled.