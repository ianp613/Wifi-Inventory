Sole PHP Archive Copyright © PID 2021
--------------------------------------------------------------------------------------
Note: This library extention works only with sole php framework version 6.0 and above.
      This library only support zip, gz, and rar file extraction. It doesn't support compression at the moment.